<!-- firebase.js: include this in each HTML before app.js -->
<script src="https://www.gstatic.com/firebasejs/10.12.2/firebase-app-compat.js"></script>
<script src="https://www.gstatic.com/firebasejs/10.12.2/firebase-auth-compat.js"></script>
<script src="https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore-compat.js"></script>
<script>
  // Firebase config (Goopy project)
  const firebaseConfig = {
    apiKey: "AIzaSyAef4RwoDNL64bKGPMb8WlcRzG6NFhmr8M",
    authDomain: "goopy-d4d8d.firebaseapp.com",
    projectId: "goopy-d4d8d",
    storageBucket: "goopy-d4d8d.firebasestorage.app",
    messagingSenderId: "93513209065",
    appId: "1:93513209065:web:ca303b265bda4ccc724c78",
    measurementId: "G-SWDEG4YLRM"
  };
  // Initialize
  try {
    firebase.initializeApp(firebaseConfig);
    window.GoopyAuth = firebase.auth();
    window.GoopyDB = firebase.firestore();
    console.log('Firebase initialized (compat)');
  } catch (e) {
    console.error('Firebase init error', e);
  }
</script>
